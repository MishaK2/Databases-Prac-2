package io.github.wasp_stdnt.prac2project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prac2ProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
