package io.github.wasp_stdnt.prac2project.external;

import io.github.wasp_stdnt.prac2project.model.Movie;

import java.util.Optional;

public interface ExternalApiService {
    Optional<Movie> fetchMovie (final Long tmdbId);
}
