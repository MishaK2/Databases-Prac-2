package io.github.wasp_stdnt.prac2project.cache;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Map;
import java.util.Optional;

@Service
public class RedisCacheService<T> implements CacheService<T> {
    private final RedisTemplate<String, Object> redisTemplate;
    private final ValueOperations<String, Object> valueOps;

    public RedisCacheService(final RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
        this.valueOps = this.redisTemplate.opsForValue();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Optional<T> get(String key) {
        Object value = valueOps.get(key);
        return (Optional<T>) Optional.ofNullable(value);
    }

    @Override
    public void put(String key, T value, Duration ttl) {
        valueOps.set(key, value, ttl);
    }

    @Override
    public void putAll(Map<String, T> entries, Duration ttl) {
        entries.forEach((key, val) -> valueOps.set(key, val, ttl));
    }

    @Override
    public void evict(String key) {
        redisTemplate.delete(key);
    }
}
