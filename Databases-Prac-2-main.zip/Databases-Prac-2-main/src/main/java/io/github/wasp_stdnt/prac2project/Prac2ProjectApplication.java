package io.github.wasp_stdnt.prac2project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class Prac2ProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(Prac2ProjectApplication.class, args);
    }

}
