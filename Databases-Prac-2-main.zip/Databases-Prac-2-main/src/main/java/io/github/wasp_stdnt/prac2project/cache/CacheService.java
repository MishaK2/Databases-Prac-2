package io.github.wasp_stdnt.prac2project.cache;

import java.time.Duration;
import java.util.Map;
import java.util.Optional;

public interface CacheService<T> {
    Optional<T> get (final String key);

    void put (final String key, final T value, Duration ttl);

    void putAll(final Map<String, T> entries, final Duration ttl);

    void evict(final String key);
}
