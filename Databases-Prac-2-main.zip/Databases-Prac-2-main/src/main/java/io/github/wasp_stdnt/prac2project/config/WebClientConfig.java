package io.github.wasp_stdnt.prac2project.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

@Configuration
public class WebClientConfig {
    @Bean
    public WebClient tmdbWebClient(
            @Value("${tmdb.api.base-url}") String baseUrl,
            @Value("${tmdb.api.key") String apiKey) {

        ExchangeFilterFunction authHeaderFilter = (request, next) -> {
            var url = UriComponentsBuilder
                    .fromUri(request.url())
                    .queryParam("api_key", apiKey)
                    .build()
                    .toUri();

            ClientRequest authorized = ClientRequest.from(request)
                    .url(url)
                    .build();

            return next.exchange(authorized);
        };

        return WebClient.builder()
                .baseUrl(baseUrl)
                .filter(authHeaderFilter)
                .build();
    }
}
