package io.github.wasp_stdnt.prac2project.controller;

import io.github.wasp_stdnt.prac2project.model.Movie;
import io.github.wasp_stdnt.prac2project.service.MovieService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movies")
public class MovieController {

    private final MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/{tmdbId}")
    public ResponseEntity<Movie> getMovie(@PathVariable Long tmdbId) {
        Movie movie = movieService.getMovie(tmdbId);
        return ResponseEntity.ok(movie);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Movie>> searchByTitle(@RequestParam String title) {
        List<Movie> results = movieService.searchByTitle(title);
        return ResponseEntity.ok(results);
    }

    @DeleteMapping("/{tmdbId}/cache")
    public ResponseEntity<Void> evictCache(@PathVariable Long tmdbId) {
        movieService.evictCache(tmdbId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/cache/preload")
    public ResponseEntity<Void> preloadCache(@RequestBody List<Movie> movies) {
        movieService.preloadCache(movies);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
