package io.github.wasp_stdnt.prac2project.service;

import io.github.wasp_stdnt.prac2project.cache.CacheService;
import io.github.wasp_stdnt.prac2project.model.Movie;
import io.github.wasp_stdnt.prac2project.external.ExternalApiService;
import io.github.wasp_stdnt.prac2project.repository.MovieRepo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class MovieServiceImpl implements MovieService {

    private static final Duration CACHE_TTL = Duration.ofMinutes(30);

    private final CacheService<Movie> cache;
    private final MovieRepo repo;
    private final ExternalApiService external;

    public MovieServiceImpl(CacheService<Movie> cache,
                            MovieRepo repo,
                            ExternalApiService external) {
        this.cache = cache;
        this.repo = repo;
        this.external = external;
    }

    @Override
    public Movie getMovie(Long tmdbId) {
        String key = cacheKey(tmdbId);

        Optional<Movie> fromCache = cache.get(key);
        if (fromCache.isPresent()) {
            return fromCache.get();
        }

        Optional<Movie> fromDb = repo.findByTmdbId(tmdbId);
        if (fromDb.isPresent()) {
            cache.put(key, fromDb.get(), CACHE_TTL);
            return fromDb.get();
        }

        Movie fetched = external.fetchMovie(tmdbId)
                .orElseThrow(() ->
                        new NoSuchElementException("Movie " + tmdbId + " not found"));

        Movie saved = repo.save(fetched);
        cache.put(key, saved, CACHE_TTL);
        return saved;
    }

    @Override
    public List<Movie> searchByTitle(String title) {
        return repo.findByTitleContainingIgnoreCase(title);
    }

    @Override
    public void evictCache(Long tmdbId) {
        cache.evict(cacheKey(tmdbId));
    }

    @Override
    public void preloadCache(List<Movie> movies) {
        Map<String, Movie> map = movies.stream()
                .collect(Collectors.toMap(m -> cacheKey(m.getTmdbId()), m -> m));
        cache.putAll(map, CACHE_TTL);
    }

    private String cacheKey(Long tmdbId) {
        return "movie:" + tmdbId;
    }
}
