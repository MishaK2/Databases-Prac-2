package io.github.wasp_stdnt.prac2project.repository;

import io.github.wasp_stdnt.prac2project.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MovieRepo extends JpaRepository<Movie, Long> {
    Optional<Movie> findByTmdbId (final Long tmdbId);

    List<Movie> findByTitleContainingIgnoreCase(final String title);
}
