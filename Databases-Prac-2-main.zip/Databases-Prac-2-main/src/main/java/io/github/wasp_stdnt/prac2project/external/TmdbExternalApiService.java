package io.github.wasp_stdnt.prac2project.external;

import io.github.wasp_stdnt.prac2project.model.Movie;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Service
public class TmdbExternalApiService implements ExternalApiService {
    private final WebClient webClient;

    public TmdbExternalApiService(WebClient tmdbWebClient) {
        this.webClient = tmdbWebClient;
    }

    @Override
    public Optional<Movie> fetchMovie(final Long tmdbId) {
        try {
            TmdbMovieDto dto = webClient.get()
                    .uri(uriBuilder -> uriBuilder.path("/movie/{id}").build(tmdbId))
                    .retrieve()
                    .onStatus(
                            status -> status == HttpStatus.NOT_FOUND,
                            resp -> Mono.empty()
                    )
                    .onStatus(
                            status -> status.is4xxClientError(),
                            ClientResponse::createException
                    )
                    .bodyToMono(TmdbMovieDto.class)
                    .block();

            if (dto == null) {
                return Optional.empty();
            }

            Movie movie = Movie.builder()
                    .tmdbId(dto.getId())
                    .title(dto.getTitle())
                    .overview(dto.getOverview())
                    .releaseDate(dto.getReleaseDate())
                    .posterPath(dto.getPosterPath())
                    .popularity(dto.getPopularity())
                    .voteAverage(dto.getVoteAverage())
                    .voteCount(dto.getVoteCount())
                    .build();

            return Optional.of(movie);

        } catch (WebClientResponseException.NotFound nf) {
            return Optional.empty();
        } catch (WebClientResponseException e) {
            throw new RuntimeException("TMDB API error: " + e.getStatusCode(), e);
        } catch (Exception e) {
            throw new RuntimeException("Unexpected error calling TMDB", e);
        }
    }
}
