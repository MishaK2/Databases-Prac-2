package io.github.wasp_stdnt.prac2project.service;

import io.github.wasp_stdnt.prac2project.model.Movie;

import java.util.List;

public interface MovieService {
    Movie getMovie (final Long tmdbId);

    List<Movie> searchByTitle (final String title);

    void evictCache (final Long tmdbId);

    void preloadCache (List<Movie> movies);
}
